package edu.bhcc.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RemainingRepository extends JpaRepository<Remaining, Long> {

    Remaining findByRemainingId(Long id);
}
