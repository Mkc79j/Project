package edu.bhcc.demo;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class WebController {
    private UserRepository userRepo;
    private RemainingRepository remainingRepo;

    /**
     * Create Budget Controller.
     */
    public WebController(UserRepository userRepo,
                         RemainingRepository remainingRepo) {
        this.userRepo = userRepo;
        this.remainingRepo = remainingRepo;
    }

    @GetMapping("/")
    public String index(Model model) {
        addUsersAndRemaining (model);
        return "index";
    }

    @GetMapping("/add_user")
    public String addUser(String payee, String category, String amount, Model model) {
        User user = new User (payee, category, amount);
        userRepo.save (user);
        model.addAttribute ("budget", "New Transactions added:  " + amount);
        addUsersAndRemaining (model);
        return "index";
    }

    @GetMapping("/add_remaining")
    public String addRemaining(String amount, String remaining, Model model) {
        User user = userRepo.findByAmount(amount);
        if (user != null) {
            Remaining newRemaining = new Remaining();
            newRemaining.setRemaining(Double.parseDouble(remaining));
            newRemaining.setUser(user);
            remainingRepo.save(newRemaining);
            model.addAttribute("budget", "New remaining saved.");
        } else {
            model.addAttribute("budget", "Could not find user: " + amount);
        }
        addUsersAndRemaining(model);
        return "index";
    }


    @GetMapping("/delete_user")
    public String deleteUser(Long id, Model model) {
        User user = userRepo.findByUserId (id);
        if (user != null) {
            userRepo.delete (user);
            model.addAttribute ("budget", "Deleted user:  " + user.getAmount ());
        } else {
            model.addAttribute ("budget", "Could not find user ID:  " + id);
        }
        addUsersAndRemaining (model);
        return "index";
    }

    @GetMapping("/delete_remaining")
    public String deleteRemaining(Long id, Model model) {
        Remaining remaining = remainingRepo.findByRemainingId (id);
        if (remaining != null) {
            remainingRepo.delete (remaining);
            model.addAttribute ("budget", "Deleted remaining");
        } else {
            model.addAttribute ("budget", "Could not find remaining ID:  " + id);
        }
        addUsersAndRemaining (model);
        return "index";
    }

    private void addUsersAndRemaining(Model model) {
        List<User> userList = getAllUsers ();
        List<Remaining> remainingList = getAllRemaining ();
        model.addAttribute ("user_list", userList);
        model.addAttribute ("remaining_list", remainingList);
    }

    private List<User> getAllUsers() {
        List<User> userList = new ArrayList<> ();
        for (User currentUser : userRepo.findAll ()) {
            userList.add ((currentUser));
        }
        return userList;
    }

    private List<Remaining> getAllRemaining() {
        List<Remaining> remainingList = new ArrayList<> ();
        for (Remaining currentRemaining : remainingRepo.findAll ()) {
            remainingList.add ((currentRemaining));
        }
        return remainingList;
    }
}
