package edu.bhcc.demo;

import jakarta.persistence.*;

@Entity
@Table(name = "remaining")
public class Remaining {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long remainingId;

    @Column(name = "remaining")
    private Double remaining;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    public Remaining() {}

    public Remaining(Double remaining, User user) {
        this.remaining = remaining;
        this.user = user;
    }

    public Long getRemainingId() {
        return remainingId;
    }

    public void setRemainingId(Long remainingId) {
        this.remainingId = remainingId;
    }

    public Double getRemaining() {
        return remaining;
    }

    public void setRemaining(Double remaining) {
        this.remaining = remaining;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
