package edu.bhcc.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    User findByAmount(String payee);

    User findBycategory(String category);

    User findByUserId(Long id);
}

