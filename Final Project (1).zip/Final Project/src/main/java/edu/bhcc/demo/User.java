package edu.bhcc.demo;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * User Object.
 */
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long userId;
    private String payee;
    private String category;
    private String amount;

    @OneToMany(mappedBy="user", orphanRemoval=true)
    private List<Remaining> remaining;

    /**
     * Protected Constructor, used by JPA..
     */
    protected User() {
    }

    /**
     * Public Constructor.
     */
    public User(String payee, String category, String amount) {
        this.payee = payee;
        this.category = category;
        this.amount = amount;
        this.remaining = new ArrayList<>();
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPayee() {
        return payee;
    }

    public void setPayee(String payee) {
        this.payee = payee;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public List<Remaining> getRemaining() {
        return remaining;
    }

    public void setRemaining(List<Remaining> remaining) {
        this.remaining = remaining;
    }
}
