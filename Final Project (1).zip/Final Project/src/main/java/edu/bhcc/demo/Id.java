package edu.bhcc.demo;

public @interface Id {
}
